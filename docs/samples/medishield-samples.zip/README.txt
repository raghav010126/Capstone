MediShield synthetic samples: 22 documents across 6 complete cases.
Includes complete representative bundles with at least 20 documents, both policies,
original labels, expected fields and synthetic member/history records. No real patient data.
Extract, then evaluate with: python eval/run_eval.py --dataset EXTRACTED_PATH --split all
See repository README for dependencies and model setup. Labels retain known generator limitations.
